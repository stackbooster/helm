# OpenTelemetry Instrumentation Layer Deployment Guide

This guide explains how to deploy the OpenTelemetry instrumentation layer alongside the StackBooster Agent chart. The instrumentation layer is required for collecting and forwarding telemetry data to your monitoring system.

## Overview

Starting with StackBooster Agent chart v1.0.11, OpenTelemetry (OTEL) support is included in the chart. However, the instrumentation layer, which specifies remote-write configuration, needs to be deployed separately as an additional layer by the customer.

## Prerequisites

- Kubernetes cluster with StackBooster Agent v1.0.11 or later installed
- Helm v3.x
- OpenTelemetry Collector endpoint (if using an existing collector)

## Deployment Steps

### 1. Enable OpenTelemetry in StackBooster Agent

First, ensure that the OpenTelemetry feature is enabled in your StackBooster Agent installation:

```yaml
# values.yaml
otel:
  enabled: true
```

Apply this configuration:

```bash
helm upgrade --install stackbooster chart/stackbooster-agent \
  --namespace stackbooster \
  --create-namespace \
  --set otel.enabled=true \
  --values values.yaml
```

### 2. Create OpenTelemetry Instrumentation Configuration

Create a file named `otel-instrumentation.yaml` with the following content, adjusting the values according to your environment:

```yaml
apiVersion: opentelemetry.io/v1alpha1
kind: Instrumentation
metadata:
  name: otel-instrumentation
  namespace: stackbooster
spec:
  exporter:
    endpoint: http://otel-collector:4317  # Replace with your collector endpoint
  propagators:
    - tracecontext
    - baggage
    - b3
  sampler:
    type: parentbased_traceidratio
    argument: "1.0"  # Sample 100% of traces
  # Specify which resources to instrument
  resource:
    # Add custom attributes to your telemetry data
    attributes:
      - name: service.namespace
        value: "stackbooster"
      - name: deployment.environment
        value: "production"  # Adjust as needed
  # Language-specific instrumentation settings
  java:
    image: ghcr.io/open-telemetry/opentelemetry-operator/autoinstrumentation-java:latest
    resources:
      limits:
        cpu: 500m
        memory: 128Mi
      requests:
        cpu: 50m
        memory: 64Mi
  nodejs:
    image: ghcr.io/open-telemetry/opentelemetry-operator/autoinstrumentation-nodejs:latest
  python:
    image: ghcr.io/open-telemetry/opentelemetry-operator/autoinstrumentation-python:latest
  dotnet:
    image: ghcr.io/open-telemetry/opentelemetry-operator/autoinstrumentation-dotnet:latest
  go:
    image: ghcr.io/open-telemetry/opentelemetry-operator/autoinstrumentation-go:latest
```

### 3. Apply the Instrumentation Configuration

Apply the instrumentation configuration to your cluster:

```bash
kubectl apply -f otel-instrumentation.yaml
```

### 4. Configure Remote Write (Optional)

If you need to configure remote write to send telemetry data to an external system, add the following to your instrumentation configuration:

```yaml
spec:
  exporter:
    endpoint: http://otel-collector:4317
    otlphttp:
      headers:
        Authorization: "Bearer <your-token>"  # If authentication is required
    otlp:
      endpoint: https://your-remote-endpoint:4317  # Remote endpoint
      headers:
        Authorization: "Bearer <your-token>"  # If authentication is required
```

## Verifying the Deployment

To verify that the instrumentation is working correctly:

1. Check that the instrumentation resource is created:

```bash
kubectl get instrumentation -n stackbooster
```

2. Check the logs of your applications to see if they are being instrumented:

```bash
kubectl logs -l app=your-application -n your-namespace
```

Look for log entries related to OpenTelemetry instrumentation.

## Troubleshooting

### Common Issues

1. **Instrumentation not applied to pods**
   - Ensure that the OpenTelemetry Operator is running
   - Check that your pods have the necessary annotations for auto-instrumentation

2. **No telemetry data being collected**
   - Verify that the exporter endpoint is correct and accessible
   - Check the OpenTelemetry Collector logs for any errors

3. **Performance issues after instrumentation**
   - Adjust the sampling rate in the instrumentation configuration
   - Review resource limits for the instrumentation agents

## Additional Resources

- [OpenTelemetry Documentation](https://opentelemetry.io/docs/)
- [OpenTelemetry Operator GitHub](https://github.com/open-telemetry/opentelemetry-operator)
- [OpenTelemetry Collector Documentation](https://opentelemetry.io/docs/collector/)