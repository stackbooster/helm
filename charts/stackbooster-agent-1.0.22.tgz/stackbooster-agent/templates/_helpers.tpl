{{/*
Expand the name of the chart.
*/}}
{{- define "stackbooster-agent.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "stackbooster-agent.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "stackbooster-agent.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "stackbooster-agent.labels" -}}
helm.sh/chart: {{ include "stackbooster-agent.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "stackbooster-agent.controllerSelectorLabels" -}}
app.kubernetes.io/name: {{ include "stackbooster-agent.fullname" . }}-controller
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "stackbooster-agent.agentSelectorLabels" -}}
app.kubernetes.io/name: {{ include "stackbooster-agent.fullname" . }}-agent
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "stackbooster-agent.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "stackbooster-agent.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/* ---------------- SCHEDULER HELPERS ---------------- */}}

{{/* Scheduler name */}}
{{- define "stackbooster-scheduler.name" -}}
stackbooster-scheduler
{{- end }}

{{/* Scheduler full name */}}
{{- define "stackbooster-scheduler.fullname" -}}
{{ printf "%s-scheduler" (include "stackbooster-agent.fullname" .) }}
{{- end }}

{{/* Scheduler service account name */}}
{{- define "stackbooster-scheduler.serviceAccountName" -}}
stackbooster-scheduler
{{- end }}

{{/* ---------------- SCHEDULER CONTROLLER HELPERS ---------------- */}}

{{- define "scheduler-controller.name" -}}
stackbooster-scheduler-controller
{{- end }}

{{- define "scheduler-controller.fullname" -}}
stackbooster-scheduler-controller
{{- end }}

{{- define "scheduler-controller.serviceAccountName" -}}
stackbooster-scheduler-controller
{{- end }}

{{/* ================================================================ */}}
{{/*  Default storage-class checker                                   */}}
{{/* ================================================================ */}}

{{- define "checkDefaultStorageClass" -}}

{{- /* List all StorageClasses */ -}}
{{- $scs := lookup "storage.k8s.io/v1" "StorageClass" "" "" }}
{{- $hasDefault := false }}

{{- if $scs }}
  {{- range $scs.items }}
    {{- $a := .metadata.annotations }}
    {{- if or
          (eq (get $a "storageclass.kubernetes.io/is-default-class") "true")
          (eq (get $a "storageclass.beta.kubernetes.io/is-default-class") "true") }}
      {{- $hasDefault = true }}
    {{- end }}
  {{- end }}
{{- end }}

{{- if not $hasDefault }}
  {{ fail "\n\n🚫  No *default* StorageClass detected in this cluster.\n    ➜  Mark one as default:\n        kubectl annotate storageclass <name> storageclass.kubernetes.io/is-default-class=true\n" }}
{{- end }}

{{- end }}{{/* define checkDefaultStorageClass */}}

{{/*
Controller image tag.
`helm upgrade --reuse-values` keeps the tag stored by the previously installed chart version, so
upgrading the chart alone would leave the old controller running. A plain numeric tag that is older
than the controller this chart version requires is therefore raised to that minimum; newer tags and
custom (non-numeric) tags are used exactly as given.
Bump the minimum only when a chart release must not run with an older controller.
*/}}
{{- define "stackbooster-agent.controllerImageTag" -}}
{{- $min := "8.25" -}}
{{- $tag := toString .Values.images.controller.tag -}}
{{- if and (regexMatch "^[0-9]+\\.[0-9]+(\\.[0-9]+)?$" $tag) (semverCompare (printf "<%s" $min) $tag) -}}
{{- $min -}}
{{- else -}}
{{- $tag -}}
{{- end -}}
{{- end }}
