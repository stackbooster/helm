# StackBooster Metrics Configuration Guide

This guide will help you configure the `metricsConfig` section in your StackBooster Helm values file.

## Basic Configuration Structure

```yaml
metricsConfig:
  api: api.stackbooster.io  # This is fixed, do not change
  prometheus:
    url: "prometheus-server.<your-prometheus-namespace>.svc.cluster.local:80"
    credentials:
      basic:
        fromSecret: <secret-name>
  victoriaMetrics:
    url: <victoria-metrics-url>
    credentials:
      basic:
        fromSecret: <secret-name>
```

## Step-by-Step Configuration Guide

### 1. Configure Prometheus URL

To find your Prometheus URL:

```bash
# Get your Prometheus service details
kubectl get svc prometheus-server -n <your-prometheus-namespace>

# Example output:
# NAME                TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)    AGE
# prometheus-server   ClusterIP   10.96.123.456    <none>        9090/TCP   1d
```

Use this format for the URL:
```yaml
prometheus:
  url: "prometheus-server.<your-prometheus-namespace>.svc.cluster.local:80"
```

### 2. Configure VictoriaMetrics URL

For reading metrics, you'll need to configure VMSelect. If you're using VMAuth for authentication, you'll need to configure that as well.

To find your VictoriaMetrics services:

```bash
# Get your VictoriaMetrics service details
kubectl get svc -n <your-vm-namespace> | grep vm

# Example output:
# NAME         TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)    AGE
# vmselect     ClusterIP   10.96.123.456    <none>        8481/TCP   1d
# vmauth       ClusterIP   10.96.123.457    <none>        8427/TCP   1d
```

Use one of these formats for the URL:

1. If using VMSelect directly:
```yaml
victoriaMetrics:
  url: "http://vmselect.<your-vm-namespace>.svc.cluster.local:8481"
```

2. If using VMAuth (recommended for authentication):
```yaml
victoriaMetrics:
  url: "http://vmauth.<your-vm-namespace>.svc.cluster.local:8427"
```

### 3. Create Authentication Secrets

Create secrets in the same namespace where Prometheus and VictoriaMetrics are deployed:

```bash
# Create Prometheus secret in the Prometheus namespace
kubectl create secret generic prometheus-auth \
  --from-literal=username=<your-prometheus-username> \
  --from-literal=password=<your-prometheus-password> \
  -n <your-prometheus-namespace>

# Create VictoriaMetrics secret in the VictoriaMetrics namespace
kubectl create secret generic victoria-auth \
  --from-literal=username=<your-vm-username> \
  --from-literal=password=<your-vm-password> \
  -n <your-vm-namespace>

# Verify the secrets were created correctly
kubectl get secret prometheus-auth -n <your-prometheus-namespace> -o yaml
kubectl get secret victoria-auth -n <your-vm-namespace> -o yaml
```

The secrets should contain both `username` and `password` fields. You can verify this by checking the output of the last two commands - they should show both fields in the `data` section.

### 4. Complete Configuration Example

Here's a complete example with all values filled in:

```yaml
metricsConfig:
  api: api.stackbooster.io
  prometheus:
    url: "prometheus-server.monitoring.svc.cluster.local:80"
    credentials:
      basic:
        fromSecret: prometheus-auth
  victoriaMetrics:
    url: "http://vmauth.victoria-metrics.svc.cluster.local:8427"  # Using VMAuth for authentication
    credentials:
      basic:
        fromSecret: victoria-auth
```

## Installation

### 1. Build Dependencies

First, build all the required Helm chart dependencies:

```bash
cd chart/stackbooster-agent
helm dependency build subcharts/federation && helm dependency build subcharts/metricsfull && helm dependency build subcharts/otel && helm dependency build .
```

### 2. Install the Chart

Navigate to the chart directory and install the StackBooster Agent:

```bash
helm upgrade --install stackbooster chart/stackbooster-agent \
  --namespace stackbooster \
  --create-namespace \
  --set agentMode=readonly \
  --set cloudProvider=<azure/aws> .
```



## Best Practices

1. **Use Internal URLs**: Always use internal Kubernetes DNS names (`.svc.cluster.local`) for better security and reliability
2. **Namespace Consistency**: Keep secrets in the same namespace as their respective services (Prometheus/VictoriaMetrics)
3. **Secret Management**: Use meaningful secret names and keep credentials secure
4. **URL Verification**: Test your URLs before deployment:
   ```bash
   # Test Prometheus
   kubectl run -it --rm debug --image=curlimages/curl -- sh
   curl prometheus-server.<namespace>.svc.cluster.local:80/-/healthy
   
   # Test VictoriaMetrics (VMSelect)
   curl vmselect.<namespace>.svc.cluster.local:8481/health
   
   # Test VictoriaMetrics (VMAuth)
   curl vmauth.<namespace>.svc.cluster.local:8427/health
   ```

## Troubleshooting

If you encounter issues:

1. **Service Not Found**
   - Verify service names and namespaces
   - Check if services are running: `kubectl get svc -n <namespace>`

2. **Authentication Issues**
   - Verify secrets exist: `kubectl get secret -n <namespace>`
   - Check secret contents: `kubectl describe secret <secret-name> -n <namespace>`

3. **Connection Issues**
   - Ensure services are in the same cluster
   - Check network policies allow communication
   - Verify service endpoints: `kubectl get endpoints -n <namespace>` 
