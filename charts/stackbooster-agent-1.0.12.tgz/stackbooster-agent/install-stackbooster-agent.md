# StackBooster Agent Installation Guide (Public Helm Chart)

This guide explains how to install the public StackBooster Agent chart in your Kubernetes cluster using Helm.

Important notes:
- You will install the public chart from the StackBooster Helm repository (not from this private repo).
- The agent requires a default StorageClass to be present in the cluster.
- The agent requires cert-manager to be installed (CRDs must be enabled).

## Prerequisites

- Kubernetes cluster (v1.23+ recommended)
- kubectl and Helm v3 installed
- Cluster admin permissions to install CRDs and annotate StorageClass

## Add Helm Repositories

```bash
helm repo add jetstack https://charts.jetstack.io
helm repo add stackbooster https://raw.githubusercontent.com/stackbooster/helm/main/charts
helm repo update
```

## Install cert-manager

Install cert-manager and its CRDs (required by StackBooster):

```bash
echo "Install cert manager"
helm install cert-manager jetstack/cert-manager \
  --namespace cert-manager \
  --create-namespace \
  --version v1.17.0 \
  --set crds.enabled=true
```

Verify cert-manager:

```bash
kubectl get pods -n cert-manager
```

## Ensure a Default StorageClass Exists

StackBooster requires a default StorageClass. If your cluster already has a default StorageClass, you can skip this step:

```bash
kubectl get storageclass
```

If you need to set an existing StorageClass (for example, `gp2` on AWS) as default:

```bash
kubectl annotate storageclass gp2 storageclass.kubernetes.io/is-default-class=true --overwrite=true
```

Replace `gp2` with your StorageClass name if different (e.g., `gp3`, `standard`, etc.).

## Install StackBooster Agent

Install the public StackBooster Agent chart (example uses version 1.0.10):

```bash
echo "Install stackbooster"
helm upgrade --install stackbooster stackbooster/stackbooster-agent \
  --namespace stackbooster \
  --create-namespace \
  --version 1.0.10
```

## How to Customize Values (no access to this repo's values.yaml)

Since this repository is private, you won’t edit its values.yaml directly. Use one of the following approaches:

1) Generate a baseline values file from the public chart and modify it:

```bash
helm show values stackbooster/stackbooster-agent --version 1.0.10 > sb-values.yaml
# Edit sb-values.yaml and then install/upgrade with it
helm upgrade --install stackbooster stackbooster/stackbooster-agent \
  --namespace stackbooster \
  --create-namespace \
  --version 1.0.10 \
  -f sb-values.yaml
```

2) Or use --set flags for a small number of overrides, for example:

```bash
helm upgrade --install stackbooster stackbooster/stackbooster-agent \
  --namespace stackbooster \
  --create-namespace \
  --version 1.0.10 \
  --set agentMode=readonly \
  --set cloudProvider=aws
```

For metrics endpoints configuration (Prometheus, VictoriaMetrics) see metricsConfig-guide.md in this directory, and replicate the settings using either `sb-values.yaml` or `--set` flags.

## Verify Installation

```bash
kubectl get pods -n stackbooster
kubectl get svc -n stackbooster
kubectl get crds | grep stackbooster || true
```

You should see StackBooster controller/agent components running without CrashLoopBackOff.

## Upgrades

To upgrade to a newer chart version later:

```bash
helm repo update
helm upgrade stackbooster stackbooster/stackbooster-agent \
  --namespace stackbooster \
  --version <new-version> \
  -f sb-values.yaml   # if you used a values file
```

## Uninstall

```bash
helm uninstall stackbooster -n stackbooster
```

## About OpenTelemetry and Instrumentation Layer

- In chart version 1.0.10, customers install the agent as shown above.
- Beginning with chart version 1.0.11 (when published), OTEL support is included in the chart, but the application instrumentation layer must be deployed separately by customers.
- For guidance on deploying the instrumentation layer (when you move to 1.0.11+), see: otel-instrumentation-guide.md

## Troubleshooting

- cert-manager pods not ready: ensure `--set crds.enabled=true` was used and all pods in `cert-manager` namespace are Running.
- No default StorageClass: annotate your preferred StorageClass as default (see step above) or create one if none exists.
- Pods CrashLooping: check logs with `kubectl logs <pod> -n stackbooster` and review your overrides in `sb-values.yaml`.